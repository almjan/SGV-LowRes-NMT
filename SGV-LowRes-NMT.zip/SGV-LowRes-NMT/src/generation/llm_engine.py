import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from typing import List

class LLMGenerator:
    """
    LLM Inference Engine using HuggingFace Transformers.

    """
    def __init__(self, config):
        self.config = config
        self.tokenizer = AutoTokenizer.from_pretrained(config.model_name)
        self.model = AutoModelForCausalLM.from_pretrained(
            config.model_name, 
            torch_dtype=torch.float16, 
            device_map="auto"
        )
        self.model.eval()

    def generate_candidates(self, prompts: List[str]) -> List[List[str]]:
        """
        Generates k candidates for a batch of prompts.
        """
        inputs = self.tokenizer(prompts, return_tensors="pt", padding=True).to(self.model.device)
        
        with torch.no_grad():
            outputs = self.model.generate(
                **inputs,
                max_new_tokens=self.config.max_new_tokens,
                temperature=self.config.temperature,
                top_p=self.config.top_p,
                num_return_sequences=self.config.num_candidates, # k=5
                do_sample=True,
                pad_token_id=self.tokenizer.eos_token_id
            )
        
        # Decode and group by input prompt
        decoded = self.tokenizer.batch_decode(outputs, skip_special_tokens=True)
        
        # Reshape list to [batch_size, k]
        k = self.config.num_candidates
        candidates = [decoded[i:i + k] for i in range(0, len(decoded), k)]
        
        return candidates