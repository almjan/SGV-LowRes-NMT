import torch
from torch.utils.data import Dataset
import pandas as pd
from transformers import AutoTokenizer

class VerifierDataset(Dataset):
    """
    Dataset for training the Dual-Encoder Fusion Verifier.
    Paper Ref: Section 4.1.2 (Transfer Learning Data)
    Expects triplets or pairs: (Source, Target_Pos, Target_Neg) for contrastive learning
    or (Source, Target, Label) for classification.
    """
    def __init__(self, data_path, labse_model_name, laser_model_name, max_len=128):
        # Assuming CSV format: src_text, tgt_text, label (1 for pos, 0 for neg)
        # Or just pos pairs if using in-batch negatives.
        self.data = pd.read_csv(data_path)
        self.max_len = max_len
        
        # We need two tokenizers because backbones might differ
        self.tokenizer_l = AutoTokenizer.from_pretrained(labse_model_name)
        # LASER usually uses a specific tokenizer or raw bytes, here assuming HF wrapper
        # If using standard LASER, you might not use HF tokenizer, but for code consistency
        # we assume a HF-compatible tokenizer or wrapper exists.
        self.tokenizer_s = AutoTokenizer.from_pretrained(laser_model_name)

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        row = self.data.iloc[idx]
        src_text = str(row['src'])
        tgt_text = str(row['tgt'])
        
        # Tokenize for LaBSE
        inputs_l_src = self.tokenizer_l(
            src_text, max_length=self.max_len, padding='max_length', truncation=True, return_tensors='pt'
        )
        inputs_l_tgt = self.tokenizer_l(
            tgt_text, max_length=self.max_len, padding='max_length', truncation=True, return_tensors='pt'
        )
        
        # Tokenize for LASER
        inputs_s_src = self.tokenizer_s(
            src_text, max_length=self.max_len, padding='max_length', truncation=True, return_tensors='pt'
        )
        inputs_s_tgt = self.tokenizer_s(
            tgt_text, max_length=self.max_len, padding='max_length', truncation=True, return_tensors='pt'
        )

        return {
            'src_ids_l': inputs_l_src['input_ids'].squeeze(),
            'src_mask_l': inputs_l_src['attention_mask'].squeeze(),
            'tgt_ids_l': inputs_l_tgt['input_ids'].squeeze(),
            'tgt_mask_l': inputs_l_tgt['attention_mask'].squeeze(),
            
            'src_ids_s': inputs_s_src['input_ids'].squeeze(),
            'src_mask_s': inputs_s_src['attention_mask'].squeeze(),
            'tgt_ids_s': inputs_s_tgt['input_ids'].squeeze(),
            'tgt_mask_s': inputs_s_tgt['attention_mask'].squeeze(),
        }