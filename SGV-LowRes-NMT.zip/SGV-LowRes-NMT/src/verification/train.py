import hydra
import torch
from torch.utils.data import DataLoader
from torch.optim import AdamW
from src.verification.model import DualEncoderFusion, VerifierTrainer
from src.verification.dataset import VerifierDataset
from src.utils.logger import get_logger
import os

log = get_logger(__name__)

@hydra.main(config_path="../../configs", config_name="config")
def train(cfg):
    log.info("Initializing Verifier Training...")
    
    # 1. Dataset & Dataloader
    dataset = VerifierDataset(
        data_path=cfg.paths.transfer_data, # e.g., tr-zh corpus
        labse_model_name=cfg.verifier.labse_model,
        laser_model_name=cfg.verifier.laser_model
    )
    dataloader = DataLoader(dataset, batch_size=cfg.verifier.batch_size, shuffle=True, num_workers=4)
    
    # 2. Model Setup
    fusion_model = DualEncoderFusion(cfg.verifier).to(cfg.verifier.device)
    trainer_model = VerifierTrainer(fusion_model).to(cfg.verifier.device)
    
    optimizer = AdamW(filter(lambda p: p.requires_grad, trainer_model.parameters()), lr=cfg.verifier.learning_rate)
    
    # 3. Training Loop
    log.info("Start Training...")
    trainer_model.train()
    
    for epoch in range(cfg.verifier.epochs):
        total_loss = 0
        for batch_idx, batch in enumerate(dataloader):
            # Move to device
            batch = {k: v.to(cfg.verifier.device) for k, v in batch.items()}
            
            # Forward pass (VerifierTrainer handles the complex input mapping)
            loss = trainer_model(batch)
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            total_loss += loss.item()
            
            if batch_idx % 100 == 0:
                log.info(f"Epoch {epoch} | Batch {batch_idx} | Loss: {loss.item():.4f}")
        
        avg_loss = total_loss / len(dataloader)
        log.info(f"Epoch {epoch} Completed | Avg Loss: {avg_loss:.4f}")
        
        # Save Checkpoint
        save_path = os.path.join(cfg.paths.model_save_dir, f"verifier_epoch_{epoch}.pt")
        torch.save(fusion_model.state_dict(), save_path)
        log.info(f"Saved checkpoint to {save_path}")

if __name__ == "__main__":
    train()