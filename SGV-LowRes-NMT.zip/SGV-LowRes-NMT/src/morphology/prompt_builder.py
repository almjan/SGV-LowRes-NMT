from typing import List

class IGTPromptBuilder:
    """
    Constructs the IGT-Augmented Prompt.
    """
    def __init__(self, template_type: str = "standard"):
        self.template = """
You are a professional translator for low-resource languages.
Task: Translate the following {src_lang} sentence into Chinese.
Constraint: Strictly adhere to the morphological structure provided in the IGT (Interlinear Glossed Text). Pay attention to case markers (e.g., [ABL], [ACC]) and voice (e.g., [PASS]).

Input Sentence: {src_text}
Morphological Analysis (IGT): {igt_text}

Translation:
"""
    
    def build(self, src_lang: str, src_text: str, igt_text: str) -> str:
        return self.template.format(
            src_lang=src_lang,
            src_text=src_text,
            igt_text=igt_text
        )