import numpy as np

class AdaptiveSelector:
    """
    Objective-driven Adaptive Filtering.
    """
    def __init__(self, beta: float = 0.9):
        self.beta = beta

    def select(self, candidates: list, scores: np.ndarray):
        """
        Selects top candidates based on distribution-aware threshold tau.
        """
      
        # p = 100 * (1 - beta)
        # if beta=0.9, we keep top 90%, so percentile is 10 (from bottom) ??
        # If beta=0.9 (retain 90%), we cut off bottom 10%. So p=10.
        p = 100 * (1 - self.beta)
        tau = np.percentile(scores, p)
        
        
        selected_indices = np.where(scores >= tau)[0]
        
        selected_data = [candidates[i] for i in selected_indices]
        
        print(f"Adaptive Threshold (tau): {tau:.4f}")
        print(f"Retention Ratio: {len(selected_data)/len(candidates):.2%}")
        
        return selected_data