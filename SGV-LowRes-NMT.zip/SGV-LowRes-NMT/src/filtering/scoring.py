import torch
import torch.nn.functional as F
import numpy as np
import faiss # For efficient KNN search

class SemanticScorer:
    """
    Semantic Scoring.
    Computes Score_final = alpha * Cosine + (1-alpha) * Margin
    """
    def __init__(self, config):
        self.alpha = config.alpha
        self.k = config.k_neighbors
        self.index = None # Faiss index

    def compute_scores(self, z_source: np.ndarray, z_candidates: np.ndarray) -> np.ndarray:
        """
        z_source: [N, D]
        z_candidates: [N, D] (One-to-one mapping for simplicity of scoring logic here)
        """

        # Assuming normalized vectors
        cos_sim = np.sum(z_source * z_candidates, axis=1) # [N]
        
        
        # Need to build index on candidates to find neighbors
        # For margin, we usually compare specific candidate similarity vs average similarity of neighbors
        if self.index is None:
            self._build_index(z_candidates)
            
        # Search for k nearest neighbors of source in the candidate space
        # (Margin usually defined as: cos(x, y) - avg_cos(x, nearest_neighbors_of_x_in_Y))
        D, I = self.index.search(z_source, self.k)
        
        # Average cosine similarity of neighbors
        avg_neighbor_sim = np.mean(D, axis=1) # [N] (faiss returns distances/similarities)
        
        margin_score = cos_sim - avg_neighbor_sim
        
        
        final_score = self.alpha * cos_sim + (1 - self.alpha) * margin_score
        
        return final_score

    def _build_index(self, vectors):
        d = vectors.shape[1]
        self.index = faiss.IndexFlatIP(d) # Inner Product (Cosine if normalized)
        self.index.add(vectors)