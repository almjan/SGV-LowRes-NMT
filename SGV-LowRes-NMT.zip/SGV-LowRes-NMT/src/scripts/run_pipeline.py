import hydra
from omegaconf import DictConfig
from src.morphology.analyzer import MorphAnalyzer
from src.morphology.prompt_builder import IGTPromptBuilder
from src.generation.llm_engine import LLMGenerator
from src.verification.model import DualEncoderFusion
from src.filtering.scoring import SemanticScorer
from src.filtering.selector import AdaptiveSelector
import torch

@hydra.main(config_path="../configs", config_name="config")
def main(cfg: DictConfig):
    print(f"Starting SGV Pipeline for {cfg.project_name}...")
    
    # ---------------------------
    # Stage 1: Generation 
    # ---------------------------
    print("Stage 1: Linguistically-informed Generation")
    morph_analyzer = MorphAnalyzer(lang="uz") 
    prompt_builder = IGTPromptBuilder()
    llm = LLMGenerator(cfg.generator)
    
    # Mock Data Loading
    raw_sentences = ["U kitobni o'qidi."] # Load from file in real scenario
    
    candidates = []
    prompts = []
    
    for sent in raw_sentences:
        igt = morph_analyzer.analyze(sent)
        prompt = prompt_builder.build("Uzbek", sent, igt)
        prompts.append(prompt)
        
    batch_candidates = llm.generate_candidates(prompts) # [[cand1, cand2...], ...]
    
    # Flatten for verification
    flat_sources = []
    flat_candidates = []
    for src, cands in zip(raw_sentences, batch_candidates):
        for c in cands:
            flat_sources.append(src)
            flat_candidates.append(c)
            
    # ---------------------------
    # Stage 2: Verification 
    # ---------------------------
    print("Stage 2: Dynamic Dual-Encoder Verification")
    verifier = DualEncoderFusion(cfg.verifier).to(cfg.generator.device)
    # Load pretrained weights here (verifier.load_state_dict...)
    verifier.eval()
    


    
    with torch.no_grad():
        # Dummy tensors for compilation check
        B = len(flat_sources)
        dummy_src = torch.zeros((B, 10), dtype=torch.long).to(cfg.generator.device)
        dummy_tgt = torch.zeros((B, 10), dtype=torch.long).to(cfg.generator.device)
        
        z_src, z_tgt = verifier(dummy_src, None, dummy_tgt, None)
        
    z_src_np = z_src.cpu().numpy()
    z_tgt_np = z_tgt.cpu().numpy()
    
    # ---------------------------
    # Stage 3: 
    # ---------------------------
    print("Stage 3: Adaptive Filtering")
    scorer = SemanticScorer(cfg.filtering)
    scores = scorer.compute_scores(z_src_np, z_tgt_np)
    
    selector = AdaptiveSelector(beta=cfg.filtering.beta)
    final_corpus = selector.select(flat_candidates, scores)
    
    print(f"Final Corpus Size: {len(final_corpus)}")
    # Save final_corpus to file

if __name__ == "__main__":
    main()